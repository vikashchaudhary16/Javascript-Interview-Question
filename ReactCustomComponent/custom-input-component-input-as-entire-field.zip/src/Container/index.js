import styled from "@emotion/styled";

const Container = styled.div`
  padding: 20px;
`;

export default Container;
